import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {
    private Connection conn;

    public StudentDAO() {
        conn = DatabaseConnection.getConnection();
    }

    public void addStudent(Student s) {
        try {
            String sql = "INSERT INTO students(name, roll_no, Dept, math, science, english, total, average, grade) VALUES (?, ?, ?,?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, s.getName());
            ps.setString(2, s.getRollNo());
            ps.setString(3, s.getDept());
            ps.setInt(4, s.getMath());
            ps.setInt(5, s.getScience());
            ps.setInt(6, s.getEnglish());
            ps.setInt(7, s.getTotal());
            ps.setFloat(8, s.getAverage());
            ps.setString(9, s.getGrade());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM students";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Student s = new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("Dept"),
                    rs.getString("roll_no"),
                    rs.getInt("math"),
                    rs.getInt("science"),
                    rs.getInt("english")
                );
                s.setTotal(rs.getInt("total"));
                s.setAverage(rs.getFloat("average"));
                s.setGrade(rs.getString("grade"));
                list.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void updateStudent(Student s) {
        try {
            String sql = "UPDATE students SET name=?, roll_no=?,Dept=?, math=?, science=?, english=?, total=?, average=?, grade=? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, s.getName());
            ps.setString(2, s.getRollNo());
            ps.setString(3, s.getDept());
            ps.setInt(4, s.getMath());
            ps.setInt(5, s.getScience());
            ps.setInt(6, s.getEnglish());
            ps.setInt(7, s.getTotal());
            ps.setFloat(8, s.getAverage());
            ps.setString(9, s.getGrade());
            ps.setInt(10, s.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteStudent(int id) {
        try {
            String sql = "DELETE FROM students WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public List<Student> searchStudents(String keyword) {
        List<Student> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM students WHERE name LIKE ? OR roll_no LIKE ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Student s = new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("roll_no"),
                    rs.getString("Dept"),
                    rs.getInt("math"),
                    rs.getInt("science"),
                    rs.getInt("english")
                );
                s.setTotal(rs.getInt("total"));
                s.setAverage(rs.getFloat("average"));
                s.setGrade(rs.getString("grade"));
                list.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
public class Student {
    private int id;
    private String name;
    private String rollNo;
    private String Dept;
    private int math, science, english;
    private int total;
    private float average;
    private String grade;

    // Constructor without ID (for insert)
    public Student(String name, String rollNo, String Dept,int math, int science, int english) {
        this.name = name;
        this.rollNo = rollNo;
        this.Dept = Dept;
        this.math = math;
        this.science = science;
        this.english = english;
    }

    // Constructor with ID (for update)
    public Student(int id, String name, String rollNo,String Dept, int math, int science, int english) {
        this.id = id;
        this.name = name;
        this.rollNo = rollNo;
        this.Dept = Dept;
        this.math = math;
        this.science = science;
        this.english = english;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDept() { return Dept; }
    public void setDept(String Dept) { this.Dept = Dept; }

    public String getRollNo() { return rollNo; }
    public void setRollNo(String rollNo) { this.rollNo = rollNo; }

    public int getMath() { return math; }
    public void setMath(int math) { this.math = math; }

    public int getScience() { return science; }
    public void setScience(int science) { this.science = science; }

    public int getEnglish() { return english; }
    public void setEnglish(int english) { this.english = english; }

    public int getTotal() { return total; }
    public void setTotal(int total) { this.total = total; }

    public float getAverage() { return average; }
    public void setAverage(float average) { this.average = average; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }
}

import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

public class ExportCSV {

    public static void exportToCSV() {
        String jdbcURL = "jdbc:mysql://localhost:3306/smartstudent";
        String username = "root";
        String password = "mysql";

        String csvFilePath = "students_export.csv";

        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM students");
             FileWriter csvWriter = new FileWriter(csvFilePath)) {

            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Write header
            for (int i = 1; i <= columnCount; i++) {
                csvWriter.append(metaData.getColumnName(i));
                if (i < columnCount) csvWriter.append(",");
            }
            csvWriter.append("\n");

            // Write rows
            while (resultSet.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String value = resultSet.getString(i);
                    csvWriter.append(value != null ? value : "");
                    if (i < columnCount) csvWriter.append(",");
                }
                csvWriter.append("\n");
            }

            csvWriter.flush();
            System.out.println(" Exported data to " + csvFilePath);

        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }
}

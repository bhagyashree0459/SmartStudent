// All existing imports remain the same
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class UI {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtName, txtRoll, txtDept, txtMath, txtScience, txtEnglish, txtSearch;
    private AdminService adminService = new AdminService();

    public UI() {
        initialize();
        refreshTable();
    }

    private void initialize() {
        frame = new JFrame("SmartStudent Management System");
        frame.setBounds(100, 100, 950, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblTitle = new JLabel("Student Management System");
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblTitle.setBounds(300, 10, 400, 30);
        frame.getContentPane().add(lblTitle);

        JLabel lblName = new JLabel("Name:");
        lblName.setBounds(20, 60, 80, 20);
        frame.getContentPane().add(lblName);

        txtName = new JTextField();
        txtName.setBounds(80, 60, 150, 25);
        frame.getContentPane().add(txtName);

        JLabel lblRoll = new JLabel("Roll No:");
        lblRoll.setBounds(20, 100, 80, 20);
        frame.getContentPane().add(lblRoll);

        txtRoll = new JTextField();
        txtRoll.setBounds(80, 100, 80, 25);
        frame.getContentPane().add(txtRoll);
        
        JLabel lblDept = new JLabel("Dept:");
        lblDept.setBounds(180, 100, 80, 20);
        frame.getContentPane().add(lblDept);

        txtDept = new JTextField();
        txtDept.setBounds(230, 100, 100, 25);
        frame.getContentPane().add(txtDept);
        
       
        JLabel lblMath = new JLabel("Maths:");
        lblMath.setBounds(420, 60, 80, 20);
        frame.getContentPane().add(lblMath);

        txtMath = new JTextField();
        txtMath.setBounds(470, 60, 60, 25);
        frame.getContentPane().add(txtMath);

        JLabel lblScience = new JLabel("Science:");
        lblScience.setBounds(270, 60, 60, 25);
        frame.getContentPane().add(lblScience);

        txtScience = new JTextField();
        txtScience.setBounds(330, 60, 60, 25);
        frame.getContentPane().add(txtScience);

        JLabel lblEnglish = new JLabel("English:");
        lblEnglish.setBounds(560, 60, 60, 25);
        frame.getContentPane().add(lblEnglish);

        txtEnglish = new JTextField();
        txtEnglish.setBounds(620, 60, 60, 25);
        frame.getContentPane().add(txtEnglish);

        JButton btnAdd = new JButton("Add");
        btnAdd.setBounds(350, 100, 80, 25);
        frame.getContentPane().add(btnAdd);

        JButton btnUpdate = new JButton("Update");
        btnUpdate.setBounds(450, 100, 90, 25);
        frame.getContentPane().add(btnUpdate);

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBounds(560, 100, 90, 25);
        frame.getContentPane().add(btnDelete);

        txtSearch = new JTextField();
        txtSearch.setBounds(670, 100, 120, 25);
        frame.getContentPane().add(txtSearch);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(800, 100, 80, 25);
        frame.getContentPane().add(btnSearch);

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBounds(810, 20, 100, 30);
        btnLogout.setBackground(new Color(178, 34, 34)); 
        btnLogout.setForeground(Color.WHITE);
        frame.getContentPane().add(btnLogout);

        JButton btnStats = new JButton("Statistics");
        btnStats.setBounds(700, 20, 100, 30);
        frame.getContentPane().add(btnStats);

        // Logout button action
        btnLogout.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(frame, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                frame.dispose();
                new LoginUI(); 
            }
        });

        // Statistics button action
        btnStats.addActionListener(e -> showStatistics());

        model = new DefaultTableModel();
        String[] columnNames = {"ID", "Name", "Dept", "Roll No", "Science", "Maths", "English", "Total", "Average", "Grade"};
        model.setColumnIdentifiers(columnNames);

        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 150, 900, 300);
        frame.getContentPane().add(scrollPane);

        // Row selection listener
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                txtName.setText(table.getValueAt(row, 1).toString());
                txtDept.setText(table.getValueAt(row, 2).toString());
                txtRoll.setText(table.getValueAt(row, 3).toString());
                txtMath.setText(table.getValueAt(row, 4).toString());
                txtScience.setText(table.getValueAt(row, 5).toString());
                txtEnglish.setText(table.getValueAt(row, 6).toString());
            }
        });

        // Add Button Action
        btnAdd.addActionListener(e -> {
            try {
                String name = txtName.getText();
                String roll = txtRoll.getText();
                String Dept = txtDept.getText();
                int math = Integer.parseInt(txtMath.getText());
                int science = Integer.parseInt(txtScience.getText());
                int english = Integer.parseInt(txtEnglish.getText());

                int total = math + science + english;
                float average = total / 3f;
                String grade = getGrade(average);

                Student s = new Student(total, name, roll,Dept, math, science, english);
                s.setTotal(total);
                s.setAverage(average);
                s.setGrade(grade);

                adminService.addStudent(s);
                refreshTable();
                clearForm();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input: " + ex.getMessage());
            }
        });

        // Update Button Action
        btnUpdate.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(frame, "Please select a student to update.");
                return;
            }

            try {
                int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                String name = txtName.getText();
                String roll = txtRoll.getText();
                String Dept = txtDept.getText();
                int math = Integer.parseInt(txtMath.getText());
                int science = Integer.parseInt(txtScience.getText());
                int english = Integer.parseInt(txtEnglish.getText());

                int total = math + science + english;
                float average = total / 3f;
                String grade = getGrade(average);

                Student s = new Student(id, name, roll,Dept ,math, science, english);
                s.setTotal(total);
                s.setAverage(average);
                s.setGrade(grade);

                adminService.updateStudent(s);
                refreshTable();
                clearForm();
                JOptionPane.showMessageDialog(frame, "Student updated successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input: " + ex.getMessage());
            }
        });

        // Delete Button Action
        btnDelete.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(frame, "Please select a student to delete.");
                return;
            }
            int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
            adminService.deleteStudent(id);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(frame, "Student deleted successfully!");
        
        });

        // Search Button Action
        btnSearch.addActionListener(e -> {
            String keyword = txtSearch.getText();
            List<Student> students = adminService.searchStudents(keyword);
            model.setRowCount(0);
            for (Student s : students) {
                model.addRow(new Object[]{
                    s.getId(), s.getName(), s.getRollNo(),s.getDept(),
                    s.getMath(), s.getScience(), s.getEnglish(),
                    s.getTotal(), s.getAverage(), s.getGrade()
                });
            }
        });

        frame.setVisible(true);
    }

    private void refreshTable() {
        List<Student> students = adminService.getAllStudents();
        model.setRowCount(0);
        for (Student s : students) {
            model.addRow(new Object[]{
                s.getId(), s.getName(), s.getRollNo(),s.getDept(),
                s.getMath(), s.getScience(), s.getEnglish(),
                s.getTotal(), s.getAverage(), s.getGrade()
            });
        }
    }

    private void clearForm() {
        txtName.setText("");
        txtRoll.setText("");
        txtDept.setText("");
        txtMath.setText("");
        txtScience.setText("");
        txtEnglish.setText("");
    }

    private String getGrade(float avg) {
        if (avg >= 90) return "A";
        else if (avg >= 75) return "B";
        else if (avg >= 60) return "C";
        else if (avg >= 40) return "D";
        else return "F";
    }

    private void showStatistics() {
        List<Student> students = adminService.getAllStudents();

        if (students.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No student data available.");
            return;
        }

        int totalStudents = students.size();
        float totalPercentage = 0;
        int gradeA = 0, gradeB = 0, gradeC = 0, gradeD = 0, gradeF = 0;

        for (Student s : students) {
            float avg = s.getAverage();
            totalPercentage += avg;

            String grade = s.getGrade();
            switch (grade) {
                case "A":
                    gradeA++;
                    break;
                case "B":
                    gradeB++;
                    break;
                case "C":
                    gradeC++;
                    break;
                case "D":
                    gradeD++;
                    break;
                case "F":
                    gradeF++;
                    break;
                default:
                    break;
            }
        }

        float avgPercentage = totalPercentage / totalStudents;

        String stats = "Total Students: " + totalStudents +
                       "\nAverage Percentage: " + String.format("%.2f", avgPercentage) +
                       "\nGrade A: " + gradeA +
                       "\nGrade B: " + gradeB +
                       "\nGrade C: " + gradeC +
                       "\nGrade D: " + gradeD +
                       "\nGrade F: " + gradeF;

        JOptionPane.showMessageDialog(frame, stats, "Student Statistics", JOptionPane.INFORMATION_MESSAGE);
    }


    public static void main(String[] args) {

        SwingUtilities.invokeLater(UI::new);
    }
}

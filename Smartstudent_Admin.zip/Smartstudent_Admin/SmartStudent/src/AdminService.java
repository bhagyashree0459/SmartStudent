import java.util.List;

public class AdminService {
    private StudentDAO dao = new StudentDAO();

    public void addStudent(Student s) {
        dao.addStudent(s);
    }

    public List<Student> getAllStudents() {
        return dao.getAllStudents();
    }

    public List<Student> searchStudents(String keyword) {
        return dao.searchStudents(keyword);
    }

    public void updateStudent(Student s) {
        dao.updateStudent(s);
    }

    public void deleteStudent(int id) {
        dao.deleteStudent(id); 
    }

}
# Student Management System with Admin Panel

## Features
- Admin login (default: admin / admin123)
- Add, delete, update, search students operations
- Display statistics of Marks with grade and average
- MySQL database integration via JDBC
- Swing GUI interface

## Setup
1.Import your projact into eclipse IDE
2. Create database smartstudent and import `student.sql` into database
3. Set your DB credentials in `DatabaseConnection.java`
4. Add jar file int eckipse
3. Compile and run `Main.java`
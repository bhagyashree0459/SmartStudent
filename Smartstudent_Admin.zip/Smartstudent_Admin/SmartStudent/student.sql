CREATE DATABASE IF NOT EXISTS studentdb;
USE studentdb;

CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
 	Dept VARCHAR(100),
    roll_no VARCHAR(20),
    math INT,
    science INT,
    english INT,
    total INT,
    average FLOAT,
    grade VARCHAR(2)
);
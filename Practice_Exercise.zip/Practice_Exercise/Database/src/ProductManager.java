import java.sql.*;

public class ProductManager {
    public static void main(String[] args) {
        
        String url = "jdbc:mysql://localhost:3306/testdb"; 
        String username = "root";
        String password = "mysql"; 

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            System.out.println("Connected to database.");
            String createTableSQL = "CREATE TABLE IF NOT EXISTS products (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "name VARCHAR(100), " +
                    "price DOUBLE)";
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(createTableSQL);
                System.out.println(" Table 'products' created or already exists.");
            }

            String insertSQL = "INSERT INTO products (name, price) VALUES (?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
                pstmt.setString(1, "Laptop");
                pstmt.setDouble(2, 75000);
                pstmt.executeUpdate();

                pstmt.setString(1, "Smartphone");
                pstmt.setDouble(2, 25000);
                pstmt.executeUpdate();

                pstmt.setString(1, "Headphones");
                pstmt.setDouble(2, 1500);
                pstmt.executeUpdate();

                System.out.println("3 products inserted.");
            }

            // 3. Display all products
            System.out.println("\nAll Products:");
            String selectSQL = "SELECT * FROM products";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(selectSQL)) {
                while (rs.next()) {
                    System.out.printf("ID: %d | Name: %s | Price: %.2f\n",
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getDouble("price"));
                }
            }

            // 4. Update product price
            String updateSQL = "UPDATE products SET price = ? WHERE name = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(updateSQL)) {
                pstmt.setDouble(1, 26000);
                pstmt.setString(2, "Smartphone");
                int rowsUpdated = pstmt.executeUpdate();
                if (rowsUpdated > 0)
                    System.out.println("\nProduct price updated.");
                else
                    System.out.println("\n No product found to update.");
            }

            // 5. Delete a product
            String deleteSQL = "DELETE FROM products WHERE name = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {
                pstmt.setString(1, "Headphones");
                int rowsDeleted = pstmt.executeUpdate();
                if (rowsDeleted > 0)
                    System.out.println(" Product deleted.");
                else
                    System.out.println(" No product found to delete.");
            }

            // 6. Final list of products
            System.out.println("\n Final Products:");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(selectSQL)) {
                while (rs.next()) {
                    System.out.printf("ID: %d | Name: %s | Price: %.2f\n",
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getDouble("price"));
                }
            }

        } catch (SQLException e) {
            System.out.println("❌ Database error: " + e.getMessage());
        }
    }
}

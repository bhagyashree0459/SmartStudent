import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;
public class JDBCExample {
		 public static void main(String[] args) {
		        String url = "jdbc:mysql://localhost:3306/studentdb";

		        String username = "root"; 
		        String password = "mysql"; 

		        Connection connection = null;

		        try {
		        	try (Connection conn = DriverManager.getConnection(url, username, password);
		                    Statement stmt = conn.createStatement()) {

		                   String sql = "CREATE TABLE IF NOT EXISTS employee (" +
		                                "id INT PRIMARY KEY AUTO_INCREMENT," +
		                                "name VARCHAR(50)," +
		                                "email VARCHAR(50))";

		                   stmt.executeUpdate(sql);
		                   System.out.println("Table created successfully.");

		               } catch (SQLException e) {
		                   e.printStackTrace();
		        
		            System.out.println("Connection failed! Check output console.");
		            e.printStackTrace();
		        } finally {
		            // Close connection to free resources
		            try {
		                if (connection != null) connection.close();
		            } catch (SQLException e) {
		                e.printStackTrace();
		            }
		        }
		        }
		 }
}
		    
		





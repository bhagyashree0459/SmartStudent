import java.sql.*;

public class BookManager {

    // Database connection parameters
    static final String DB_URL = "jdbc:mysql://localhost:3306/library";
    static final String USER = "root";
    static final String PASS = "mysql";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            createTable(conn);
            insertBook(conn, 1, "Java Programming", "James Gosling", 499.99);
            insertBook(conn, 2, "Effective Java", "Joshua Bloch", 599.99);
            displayBooks(conn);
            updateBookPrice(conn, 1, 549.99);
            deleteBook(conn, 2);
            displayBooks(conn);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to create books table
    public static void createTable(Connection conn) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS books (" +
                     "id INT PRIMARY KEY, " +
                     "title VARCHAR(100), " +
                     "author VARCHAR(100), " +
                     "price DOUBLE)";
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Books table created or already exists.");
        }
    }

    // Method to insert a book
    public static void insertBook(Connection conn, int id, String title, String author, double price) throws SQLException {
        String sql = "INSERT INTO books (id, title, author, price) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, title);
            pstmt.setString(3, author);
            pstmt.setDouble(4, price);
            pstmt.executeUpdate();
            System.out.println("Book inserted: " + title);
        }
    }

    // Method to display all books
    public static void displayBooks(Connection conn) throws SQLException {
        String sql = "SELECT * FROM books";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("Books List:");
            while (rs.next()) {
                System.out.printf("ID: %d, Title: %s, Author: %s, Price: ₹%.2f\n",
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getDouble("price"));
            }
        }
    }

    // Method to update book price
    public static void updateBookPrice(Connection conn, int id, double newPrice) throws SQLException {
        String sql = "UPDATE books SET price = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, newPrice);
            pstmt.setInt(2, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0)
                System.out.println("Book price updated for ID " + id);
            else
                System.out.println("Book not found.");
        }
    }

    // Method to delete a book
    public static void deleteBook(Connection conn, int id) throws SQLException {
        String sql = "DELETE FROM books WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0)
                System.out.println("Book deleted with ID " + id);
            else
                System.out.println("Book not found.");
        }
    }
}

// Employee class
class Employee {
    String name;
    int id;
    double salary;

    // Constructor
    Employee(String name, int id, double salary) {
        this.name = name;
        this.id = id;
        this.salary = salary;
    }

    // Method to display employee info
    void displayInfo() {
        System.out.println("Employee Name: " + name);
        System.out.println("Employee ID: " + id);
        System.out.println("Salary: ₹" + salary);
    }
}

// Manager subclass extending Employee
class Manager extends Employee {
    String department;

    // Constructor that calls the parent constructor using super
    Manager(String name, int id, double salary, String department) {
        super(name, id, salary); // Call to Employee constructor
        this.department = department;
    }

    // Overriding displayInfo() to show manager-specific info
    @Override
    void displayInfo() {
        super.displayInfo(); // Call method from Employee
        System.out.println("Department: " + department);
        System.out.println("Position: Manager");
    }


// Main class to test the implementation
    public static void main(String[] args) {
        // Create Manager object
        Manager manager = new Manager("Rajiv Mehta", 5001, 120000.0, "Finance");

        // Display Manager information
        manager.displayInfo();
    }
}

import java.util.StringJoiner;
import java.util.Scanner;
import java.util.Arrays;
public class StringManipulation {

	void PrintString()
	{
		Scanner scanner = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();

        // Print the entered string
        System.out.println("You entered: " + userInput);
        int len=userInput.length();
        System.out.println(len);
        scanner.close();
		
}
	void StringConcat()
	{
		Scanner scanner = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter first string: ");
        String str1 = scanner.nextLine();

        // Print the entered string
        System.out.println("You entered: " + str1);
        
        System.out.print("Enter second string: ");
        String str2 = scanner.nextLine();

        // Print the entered string
        System.out.println("You entered: " + str2);
        String concat=str1+str2;
        System.out.println("Your concat string is :"+str1+ " " +str2);
	}
	void StringCompare()
	{
		Scanner scanner = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter first string: ");
        String str1 = scanner.nextLine();

        // Print the entered string
        System.out.println("You entered: " + str1);
        
        System.out.print("Enter second string: ");
        String str2 = scanner.nextLine();

        // Print the entered string
        System.out.println("You entered: " + str2);
        
        boolean result=str1.equals(str2);
       
       System.out.println(result);
	}
	void CountVowels()
	{
		Scanner scanner = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();

        // Print the entered string
        System.out.println("Your entered String is : " + userInput);
        int count = 0;

        for (int i = 0; i < userInput.length(); i++) {
            char ch = Character.toLowerCase(userInput.charAt(i));
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                count++;
            }
        }
        
        System.out.println("Number of vowels: " + count);
        
	}
        void stringReverse()
        {
        	Scanner scanner = new Scanner(System.in);
        	String reversed = "";
        	
            // Prompt user for input
       
         System.out.println("Enter a string: ");
            String original = scanner.nextLine();

            // Print the entered string
            System.out.println("Your entered String is : " + original);

        	for (int i = original.length() - 1; i >= 0; i--) {
        	    reversed += original.charAt(i);
        	}

        	System.out.println("Reversed: " + reversed);
        
        
        scanner.close();
		
}
        void Palindrome()
        {
        	Scanner scanner = new Scanner(System.in);
        	String reversed = "";
        	
            // Prompt user for input
       
         System.out.println("Enter a string: ");
            String original = scanner.nextLine();

            // Print the entered string
            System.out.println("Your entered String is : " + original);
            for (int i = original.length() - 1; i >= 0; i--) {
                reversed += original.charAt(i);
            }

            if (original.equals(reversed)) {
                System.out.println(original + " is a palindrome.");
            } else {
                System.out.println(original + " is not a palindrome.");
            }
        scanner.close();
		
}  
    
            // Check if they are anagrams  
	private boolean areAnagrams(String str1, String str2) {
		Scanner scanner = new Scanner(System.in);

        // Input two strings
        System.out.print("Enter first string: ");
         str1 = scanner.nextLine();

        System.out.print("Enter second string: ");
        str2 = scanner.nextLine();

			// TODO Auto-generated method stub
		 if (areAnagrams(str1, str2)) {
             System.out.println("The strings are anagrams.");
         } else {
             System.out.println("The strings are NOT anagrams.");
             
         }
		 scanner.close();
		return false;	
		}
	
     
	public static void main(String[] args)
	{
		
		StringManipulation S=new StringManipulation();
		Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your choice ");
        int choice = scanner.nextInt();

		switch (choice)
		{
		case 1:
			S.PrintString();
			break;
			
		case 2:
			S.StringConcat();
			break;
		case 3:
			S.StringCompare();
			break;
		case 4:
			S.CountVowels();
			break;
		case 5:
			S.stringReverse();
			break;
		case 6:
			S.Palindrome();
			break;
		case 7:
			String str1=null;
			String str2 = null;
			S.areAnagrams(str1,str2);
		default:
			System.out.println("Invalid Operation");
		}
		
		
	}

}



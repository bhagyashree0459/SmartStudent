
class Rectangle {
    // Fields
    double length;
    double width;

    // Constructor to initialize length and width
    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

   
    public double calculateArea() {
        return length * width;
    }

    public double calculatePerimeter() {
        return 2 * (length + width);
    }

    // Method to display rectangle details
    public void displayDetails() {
        System.out.println("Length   : " + length);
        System.out.println("Width    : " + width);
        System.out.println("Area     : " + calculateArea());
        System.out.println("Perimeter: " + calculatePerimeter());
        System.out.println("-----------------------------");
    }

    public static void main(String[] args) {
        // Creating rectangle objects
        Rectangle rect1 = new Rectangle(8.5, 4.0);
        Rectangle rect2 = new Rectangle(5.1, 2.8);

        // Displaying rectangle details
        System.out.println("Rectangle Details:\n");
        rect1.displayDetails();
        rect2.displayDetails();
    
}
    }

import java.util.Scanner;

public class Array {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input array size
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();

        int[] numbers = new int[n];
        int sum = 0;

        // Input array elements
        System.out.println("Enter " + n + " numbers:");
        for(int i = 0; i < n; i++) {
            numbers[i] = scanner.nextInt();
            sum += numbers[i];
        }

        // Ask user to choose operation
        System.out.print("Type 'sum' to calculate sum or 'avg' to calculate average: ");
        String choice = scanner.next();

        if(choice.equalsIgnoreCase("sum")) {
            System.out.println("Sum of elements: " + sum);
        } else if(choice.equalsIgnoreCase("avg")) {
            double average = (double) sum / n;
            System.out.println("Average of elements: " + average);
        } else {
            System.out.println("Invalid choice!");
        }

        scanner.close();
    }
}

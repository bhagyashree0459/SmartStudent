import java.util.Scanner;
import java.util.Arrays;
public class ArrayManipulation {

	void SumAvg()
	{
		Scanner scanner = new Scanner(System.in);

        // Input array size
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();

        int[] numbers = new int[n];
		 int sum = 0;

	        // Input array elements
	        System.out.println("Enter " + n + " numbers:");
	        for(int i = 0; i < n; i++) {
	            numbers[i] = scanner.nextInt();
	            sum += numbers[i];
	        }

	        // Ask user to choose operation
	        System.out.print("Type 'sum' to calculate sum or 'avg' to calculate average: ");
	        String choice = scanner.next();

	        if(choice.equalsIgnoreCase("sum")) {
	            System.out.println("Sum of elements: " + sum);
	        } else if(choice.equalsIgnoreCase("avg")) {
	            double average = (double) sum / n;
	            System.out.println("Average of elements: " + average);
	        } else {
	            System.out.println("Invalid choice!");
	        }

	}
	void MinMax()
	{
		Scanner scanner = new Scanner(System.in);

        // Input array size
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();

        int[] numbers = new int[n];

        // Input array elements
        System.out.println("Enter " + n + " numbers:");
        for (int i = 0; i < n; i++) {
            numbers[i] = scanner.nextInt();
        }

        // Ask user for operation
        System.out.print("Type 'max' to find maximum or 'min' to find minimum: ");
        String choice = scanner.next();

        if (choice.equalsIgnoreCase("max")) {
            int max = numbers[0];
            for (int i = 1; i < n; i++) {
                if (numbers[i] > max) {
                    max = numbers[i];
                }
            }
            System.out.println("Maximum element: " + max);
        } else if (choice.equalsIgnoreCase("min")) {
            int min = numbers[0];
            for (int i = 1; i < n; i++) {
                if (numbers[i] < min) {
                    min = numbers[i];
                }
            }
            System.out.println("Minimum element: " + min);
        } 
        else {
            System.out.println("Invalid choice!");
        }
	}
        void Search()
        {
    
        	        Scanner scanner = new Scanner(System.in);

        	        // Input array size
        	        System.out.print("Enter the number of elements: ");
        	        int n = scanner.nextInt();

        	        int[] numbers = new int[n];

        	        // Input array elements
        	        System.out.println("Enter " + n + " numbers:");
        	        for (int i = 0; i < n; i++) {
        	            numbers[i] = scanner.nextInt();
        	        }

        	        // Input value to search
        	        System.out.print("Enter the value to search: ");
        	        int target = scanner.nextInt();

        	        // Linear search
        	        boolean found = false;
        	        int position = -1;
        	        for (int i = 0; i < n; i++) {
        	            if (numbers[i] == target) {
        	                found = true;
        	                position = i;
        	                break;
        	            }
        	        }

        	        // Output result
        	        if (found) {
        	            System.out.println("Value found at position (index): " + position);
        	        } else {
        	            System.out.println("Value not found in the array.");
        	        }
        }
        	        void Sort()
        	        {
        	        	   Scanner scanner = new Scanner(System.in);

        	               // Input size of the array
        	               System.out.print("Enter the number of elements: ");
        	               int n = scanner.nextInt();

        	               int[] arr = new int[n];

        	               // Input array elements
        	               System.out.println("Enter " + n + " elements:");
        	               for (int i = 0; i < n; i++) {
        	                   arr[i] = scanner.nextInt();
        	               }

        	               // Sort the array in ascending order
        	               Arrays.sort(arr);

        	               // Display the sorted array
        	               System.out.println("Sorted array in ascending order:");
        	               for (int num : arr) {
        	                   System.out.print(num + " ");
        	               }
        	        }
        	               void MatrixAddition()
        	               {
        	            	        Scanner scanner = new Scanner(System.in);

        	            	        // Input number of rows and columns
        	            	        System.out.print("Enter number of rows: ");
        	            	        int rows = scanner.nextInt();

        	            	        System.out.print("Enter number of columns: ");
        	            	        int cols = scanner.nextInt();

        	            	        int[][] matrix1 = new int[rows][cols];
        	            	        int[][] matrix2 = new int[rows][cols];
        	            	        int[][] sum = new int[rows][cols];

        	            	        // Input first matrix
        	            	        System.out.println("Enter elements of Matrix 1:");
        	            	        for (int i = 0; i < rows; i++) {
        	            	            for (int j = 0; j < cols; j++) {
        	            	                matrix1[i][j] = scanner.nextInt();
        	            	            }
        	            	        }

        	            	        // Input second matrix
        	            	        System.out.println("Enter elements of Matrix 2:");
        	            	        for (int i = 0; i < rows; i++) {
        	            	            for (int j = 0; j < cols; j++) {
        	            	                matrix2[i][j] = scanner.nextInt();
        	            	            }
        	            	        }

        	            	        // Add matrices
        	            	        for (int i = 0; i < rows; i++) {
        	            	            for (int j = 0; j < cols; j++) {
        	            	                sum[i][j] = matrix1[i][j] + matrix2[i][j];
        	            	            }
        	            	        }

        	            	        // Display result
        	            	        System.out.println("Sum of the two matrices:");
        	            	        for (int i = 0; i < rows; i++) {
        	            	            for (int j = 0; j < cols; j++) {
        	            	                System.out.print(sum[i][j] + " ");
        	            	            }
        	            	            System.out.println();
        	            	        }
        	               }
      void MatrixTranspose()
      		{
  
        Scanner scanner = new Scanner(System.in);

        // Input number of rows and columns
        System.out.print("Enter number of rows: ");
        int rows = scanner.nextInt();

        System.out.print("Enter number of columns: ");
        int cols = scanner.nextInt();

        int[][] matrix = new int[rows][cols];
        int[][] transpose = new int[cols][rows];  // Notice the size is swapped

        // Input matrix elements
        System.out.println("Enter elements of the matrix:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }

        // Transpose the matrix
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                transpose[j][i] = matrix[i][j];
            }
        }

        // Display the transposed matrix
        System.out.println("Transposed Matrix:");
        for (int i = 0; i < cols; i++) {
            for (int j = 0; j < rows; j++) {
                System.out.print(transpose[i][j] + " ");
            }
            System.out.println();
        }
      		}
     void  ReverseArray()
      {
    	    
    	        Scanner scanner = new Scanner(System.in);

    	        // Input array size
    	        System.out.print("Enter the number of elements: ");
    	        int n = scanner.nextInt();

    	        int[] arr = new int[n];

    	        // Input array elements
    	        System.out.println("Enter " + n + " elements:");
    	        for (int i = 0; i < n; i++) {
    	            arr[i] = scanner.nextInt();
    	        }

    	        // Reverse the array in-place
    	        for (int i = 0; i < n / 2; i++) {
    	            int temp = arr[i];
    	            arr[i] = arr[n - 1 - i];
    	            arr[n - 1 - i] = temp;
    	        }

    	        // Display the reversed array
    	        System.out.println("Reversed array:");
    	        for (int num : arr) {
    	            System.out.print(num + " ");
    	        }

        	        scanner.close();
        	               
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayManipulation A =new ArrayManipulation();
		
		Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your choice ");
        int choice = scanner.nextInt();

		switch (choice)
		{
		case 1:
			A.SumAvg();
			break;
			
		case 2:
			A.MinMax();
			break;
		case 3:
			A.Search();
			break;
		case 4:
			A.Sort();
			break;
		case 5:
			A.MatrixAddition();
			break;
		case 6:
			A.MatrixTranspose();
			break;
		case 7:
			A.ReverseArray();
			break;
		default:
			System.out.println("Invalid Operation");
		}
		
		
	}

}

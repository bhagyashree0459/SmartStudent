
public class Book {

			String Title;
			String author;
			int price;
		
			public Book()
			{
				Title="Swami Vivekanand";
				author="BalguruSwami";
				price=100;
				
			}
			void display()
			{
				System.out.println("Book title ="+Title);
				System.out.println("Book author ="+author);
				System.out.println("Book Price ="+price);
				
			}
			public static void main(String[] args)
			{
				Book b1=new Book();
				Book b2=new Book();
				Book b3=new Book();
				b1.display();
				b2.display();
				b3.display();
			}
	}



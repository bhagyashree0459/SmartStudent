import java.util.Scanner;

public class Calculator {

    // Method for addition
    public static double add(double a, double b) {
        return a + b;
    }

    // Method for subtraction
    public static double subtract(double a, double b) {
        return a - b;
    }

    // Method for multiplication
    public static double multiply(double a, double b) {
        return a * b;
    }

    // Method for division
    public static double divide(double a, double b) {
        if (b == 0) {
            System.out.println("Error: Cannot divide by zero.");
            return 0;
        }
        return a / b;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char repeat;

        do {
            // Input numbers
            System.out.print("Enter first number: ");
            double num1 = scanner.nextDouble();

            System.out.print("Enter second number: ");
            double num2 = scanner.nextDouble();

            // Input operation
            System.out.print("Choose operation (+, -, *, /): ");
            char operator = scanner.next().charAt(0);

            double result;

            // Switch for operations
            switch (operator) {
                case '+':
                    result = add(num1, num2);
                    System.out.println("Result: " + result);
                    break;
                case '-':
                    result = subtract(num1, num2);
                    System.out.println("Result: " + result);
                    break;
                case '*':
                    result = multiply(num1, num2);
                    System.out.println("Result: " + result);
                    break;
                case '/':
                    result = divide(num1, num2);
                    System.out.println("Result: " + result);
                    break;
                default:
                    System.out.println("Invalid operator.");
            }

            // Ask if user wants to repeat
            System.out.print("Do you want to perform another calculation? (y/n): ");
            repeat = scanner.next().charAt(0);

        } while (repeat == 'y' || repeat == 'Y');

        System.out.println("Calculator closed.");
        scanner.close();
    }
}



//Output :

//Enter first number: 54
//Enter second number: 25
//Choose operation (+, -, *, /): +
//Result: 79.0

//Do you want to perform another calculation? (y/n): y
		
//Enter first number: 23
//Enter second number: 17
//Choose operation (+, -, *, /): -
//Result: 

//Do you want to perform another calculation? (y/n): y
//Enter first number: 25
//Enter second number: 0
//Choose operation (+, -, *, /): /
//Error: Cannot divide by zero.
//Result: 0.0

//Do you want to perform another calculation? (y/n): n
//Calculator closed.


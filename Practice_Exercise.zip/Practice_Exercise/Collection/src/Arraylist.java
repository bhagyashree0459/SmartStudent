import java.util.*;

public class Arraylist {
    public static void main(String[] args) {
        ArrayList<Integer> numbers = new ArrayList<>();

        numbers.add(10);
        numbers.add(20);
        numbers.add(30);
        numbers.add(40);
        numbers.add(50);

        System.out.println("Original list: " + numbers);

        Integer valueToRemove = 30;
        if (numbers.remove(valueToRemove)) {
            System.out.println("After removing " + valueToRemove + ": " + numbers);
        } else {
            System.out.println(valueToRemove + " not found in the list.");
        }
    }
}

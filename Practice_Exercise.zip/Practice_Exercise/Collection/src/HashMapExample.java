import java.util.HashMap;

public class HashMapExample {
    public static void main(String[] args) {
        HashMap<Integer, String> students = new HashMap<>();

        students.put(101, "Alice");
        students.put(102, "Bob");
        students.put(103, "Charlie");

        System.out.println("All students: " + students);

        int rFind = 101;
        String name = students.get(rFind);
        System.out.println("Student with roll " + rFind + ": " + name);

        int Remove = 103;
        students.remove(Remove);
        System.out.println("After removing roll " + Remove + ": " + students);
    }
}

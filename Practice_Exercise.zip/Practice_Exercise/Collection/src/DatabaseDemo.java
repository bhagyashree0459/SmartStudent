import java.util.*;
public class DatabaseDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

import java.util.*;
public class Linked_list_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> carlist=new LinkedList<String>();
		carlist.add("Enova");
		carlist.add("Wagnor");
		carlist.add("Scorpio");
		carlist.add("Aulto");
		System.out.println(carlist);
		carlist.addFirst("Lambargini");
		System.out.println("List after adding first element "+carlist);
		carlist.addLast("Mercedez");
		System.out.println("List after adding last element"+carlist);
		//carlist.clear();
		carlist.pop();


		
	}

}

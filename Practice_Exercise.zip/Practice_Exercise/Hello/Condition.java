
public class Condition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=5;
		int b=6
		if(a>b)
			{
			System.out.println("A is greater");
				}
		else
		{
			System.out.println("B is greater");
		}
		
	}

}

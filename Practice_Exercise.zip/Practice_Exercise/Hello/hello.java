// A Java program to print "Hello World" 
public class GFG { 
	public static void main(String args[]) 
	{ 
		System.out.println("Hello World"); 
	} 
}

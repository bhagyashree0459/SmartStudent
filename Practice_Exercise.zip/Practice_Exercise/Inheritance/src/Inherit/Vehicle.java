package Inherit;
class Vehicle {
    String brand;
    int year;

    Vehicle(String brand, int year) {
        this.brand = brand;
        this.year = year;
    }  

    void displayInfo() {
        System.out.println("Brand: " + brand);
        System.out.println("Year: " + year);
    }
}

class Car extends Vehicle {
    String model;
    String fuelType;

    Car(String brand, int year, String model, String fuelType) {
        super(brand, year);
        this.model = model;
        this.fuelType = fuelType;
    }

    @Override
    void displayInfo() {
        super.displayInfo(); 
        System.out.println("Model: " + model);
        System.out.println("Fuel Type: " + fuelType);
    }
    public static void main(String[] args) {
        Car car1 = new Car("Scorpio", 2012, "Camry", "Diesel");
        car1.displayInfo();
    }
}

public class DebugExample {
    public static void main(String[] args) {
        int a = 5;
        int b = 0;
        int result = divide(a, b);
        System.out.println("Result: " + result);
    }

    public static int divide(int x, int y) {

        return x / y;  
    }
}

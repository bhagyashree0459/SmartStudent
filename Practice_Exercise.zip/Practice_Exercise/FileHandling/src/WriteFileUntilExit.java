import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

 class WriteToFileUntilExit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String filename = "output.txt"; // File to write to

        try {
            FileWriter writer = new FileWriter(filename, true); // 'true' to append to file
            System.out.println("Enter lines to write to the file (type 'exit' to finish):");

            while (true) {
                String input = scanner.nextLine();

                if (input.equals("exit")) {
                    break;
                }

                writer.write(input + System.lineSeparator()); // Write input line with new line
            }

            writer.close();
            System.out.println("Content successfully written to " + filename);
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}

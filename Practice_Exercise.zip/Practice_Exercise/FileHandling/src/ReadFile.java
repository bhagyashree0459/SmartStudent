import java.util.*;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileReader fr=new FileReader("gitpass.txt");
			int i;
			while((i=fr.read())!= -1) {
				System.out.println((char)i);
			}
			fr.close();
		}catch (IOException e) {
			System.out.println("Error in reading file "+e.getLocalizedMessage());
		}

	}

}

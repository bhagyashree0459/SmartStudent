import java.io.FileWriter;
import java.io.IOException;
public class FileWriting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			
		
		FileWriter fw=new FileWriter("output.txt");
		fw.write("Hello");
		fw.write("My name is Bhagyashree.n");
		fw.close();
		System.out.println("File written siccessfully.n");
	}catch(IOException e)
		{
		System.out.println("Error in writing file:"+e.getMessage());
		}
	}
}
